# task 1
print('15 * 3', type(15 * 3))
print('15 / 3', type(15 / 3))
print('15 // 3', type(15 // 3))
print('15 ** 3', type(15 ** 2))


# tasks 2-3
words = ['в', '5', 'часов', '17', 'минут', 'температура', 'воздуха', 'была', '+5', 'градусов']
for i in range(len(words) - 1, 0, -1):

    is_int = True
    for letter in words[i]:
        if letter not in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+']:
            is_int = False
            break

    if is_int and '+' in words[i]:
        words[i] = '+' + words[i].split('+')[1].zfill(2)
    elif is_int:
        words[i] = words[i].zfill(2)

    if is_int:
        words = words[0:i] + ['"', words[i].zfill(2), '"'] + words[i + 1:]

print(words)

output = words[0] + ' '
quotes_opened = False
for i in range(1, len(words)):

    if not quotes_opened:
        output += ' '

    if words[i] == '"':
        quotes_opened = not quotes_opened

    output += words[i]

print(output)


# task 4
people = ['инженер-конструктор Игорь', 'главный бухгалтер МАРИНА', 'токарь высшего разряда нИКОЛАй', 'директор аэлита']
for man in people:
    print(man.split()[-1].lower().title())


# task 5-A (string operation are not disabled in task conditions)
prices = [57.8, 46.51, 97, 12.53, 78.03, 32.4, 22.17, 6.52, 18.90, 99.12, 2.5, 12.99, 34, 65.72, 23.11]
output = ''
for price in prices:
    splitted_price = str(price).split('.')

    if len(splitted_price) == 1:
        splitted_price.append('00')

    splitted_price[1] = splitted_price[1].zfill(2)

    if output:
        output += ', '

    output += splitted_price[0] + ' руб ' + splitted_price[1] + ' коп'

print(output)


# task 5-B
for price in prices:
    print(price, ' (id:', id(price), ')', sep='')

prices.sort()
print(prices)

for price in prices:
    print(price, ' (id:', id(price), ')', sep='')


# task 5-C
prices.sort(reverse=True)
decreased_prices = prices
print(decreased_prices)


# task 5-D
top_prices = decreased_prices[:5]
top_prices.sort()
print(top_prices)
